/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.gestionexpedicionesespaciales;
import java.util.Objects;
/**

 */
public abstract class NaveEspacial {
    private String nombre;
    private int capacidadTripulacion;
    private int anioLanzamiento;

    public NaveEspacial(String nombre, int capacidadTripulacion, int anioLanzamiento) {
        this.nombre = nombre;
        this.capacidadTripulacion = capacidadTripulacion;
        this.anioLanzamiento = anioLanzamiento;
    }
    
    public int getCapacidadTripulacion(){
        return capacidadTripulacion;
    }
    public String getNombre(){
        return nombre;
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o){
            return true;
        }
        if (o == null || getClass() != o.getClass()){
            return false;
        }
        NaveEspacial nave = (NaveEspacial) o;
        return anioLanzamiento == nave.anioLanzamiento && nombre.equals(nave.nombre);
    }

    @Override
    public int hashCode() {
        return Objects.hash(nombre, anioLanzamiento);
    }
    
    public abstract String mostrarDetalles();
    
    
    
}
