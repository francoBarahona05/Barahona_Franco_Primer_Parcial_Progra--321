/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.gestionexpedicionesespaciales;


public class CruceroEstelar extends NaveEspacial{
    
    private int capacidadPasajeros;

    public CruceroEstelar(int capacidadPasajeros, String nombre, int capacidadTripulacion, int añoLanzamiento) {
        super(nombre, capacidadTripulacion, añoLanzamiento);
        this.capacidadPasajeros = capacidadPasajeros;
    }
    
    @Override
    public String mostrarDetalles(){
        return "Crucero Estelar - Nombre: " + getNombre() + ", Pasajeros: " + capacidadPasajeros;        
        
    }
    
}
