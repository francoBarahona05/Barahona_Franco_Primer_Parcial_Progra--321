
package com.mycompany.gestionexpedicionesespaciales;

/**
 *
 * @author EQUIPO
 */
public class NaveRepetidaException extends Exception{
    private static final String MESSAGE = "la nave como tal ya esta registrada en la agencia";
    
    public NaveRepetidaException(){
        super(MESSAGE);
    }
}
