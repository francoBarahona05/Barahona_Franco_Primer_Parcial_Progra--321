/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.gestionexpedicionesespaciales;

/**
 *
 */
public class NaveExploracion extends NaveEspacial implements Explorable{
    private Misiones mision;

    public NaveExploracion(Misiones mision, String nombre, int capacidadTripulacion, int añoLanzamiento) {
        super(nombre, capacidadTripulacion, añoLanzamiento);
        this.mision = mision;
    }
    @Override
    public void explorar(){
        System.out.println("La nave de exploración " + getNombre() + " está realizando una misión de " + mision);

    }
    @Override
    public String mostrarDetalles(){
        return "Nave de Exploración - Nombre: " + getNombre() + ", Misión: " + mision + ", Capacidad: " + getCapacidadTripulacion();
    }
    
}
