
package com.mycompany.gestionexpedicionesespaciales;

/**
 *
 */
public class GestionExpedicionesEspaciales {

    public static void main(String[] args) {
        AgenciaExpedicionesEspaciales agencia = new AgenciaExpedicionesEspaciales("META");

        try {
            NaveExploracion exploracion = new NaveExploracion(Misiones.INVESTIGACIÓN,"Discovery", 5, 2022);
            NaveCarguero carguero = new NaveCarguero(300,"Galáctica", 8, 2023);
            CruceroEstelar crucero = new CruceroEstelar(100,"Voyager", 10, 2021);

            agencia.agregarNaves(exploracion);
            agencia.agregarNaves(carguero);
            agencia.agregarNaves(crucero);
        } catch (NaveRepetidaException e) {
            System.out.println(e.getMessage());
        }

        agencia.mostrarNaves();
        agencia.iniciarExploracion();
    }
}
