/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.gestionexpedicionesespaciales;
import java.util.List;
import java.util.ArrayList;
/**
 *
 * @author EQUIPO
 */
public class AgenciaExpedicionesEspaciales {
    private String nombre;
    private List<NaveEspacial> naves;
    
    public AgenciaExpedicionesEspaciales(String nombre){
        this.nombre = nombre;
        naves = new ArrayList<>();
    }
    
    public void agregarNaves(NaveEspacial nave)throws NaveRepetidaException{
        if(nave == null){
            throw new NullPointerException("ingreso un NULL");
        }
        if(naves.contains(nave)){
           throw new NaveRepetidaException();
        }
        naves.add(nave);
    }
    public void mostrarNaves(){
        for(NaveEspacial nave : naves){
        System.out.println(nave.mostrarDetalles());        }
    }
    public void iniciarExploracion(){
        for(NaveEspacial nave : naves){
            if(nave instanceof Explorable){
                ((Explorable)nave).explorar();
            }else{
                System.out.println("El " + nave.getNombre() + " es un Crucero Estelar y no puede iniciar misión de exploración.");
            }
        }
    }
}
