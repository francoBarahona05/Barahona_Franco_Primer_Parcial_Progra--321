/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.gestionexpedicionesespaciales;


public class NaveCarguero extends NaveEspacial implements Explorable{
    private int cargaToneladas;
    public static final int  CAPACIDAD_MIN_TONELADAS = 100;
    public static final int CAPACIDAD_MAX_TONELADAS = 500;

    public NaveCarguero(int cargaToneladas, String nombre, int capacidadTripulacion, int añoLanzamiento) {
        super(nombre, capacidadTripulacion, añoLanzamiento);
        this.cargaToneladas = cargaToneladas;
    }
    @Override
    public void explorar(){
        System.out.println("El carguero " + getNombre() + " está iniciando una misión de transporte.");
    }
    
    @Override
    public String mostrarDetalles(){
        return "Carguero - Nombre: " + getNombre() + ", Capacidad Carga: " + cargaToneladas + " TONELADAS";
    }
    
    
}
